﻿using IronPdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Xsl;

namespace IronPDF_Ex
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HTMLD3Chart();
            ReadViaMemStream();

        }

        private void ReadViaMemStream()
        {
            //Conversion of the URL into PDF
            var Renderer = new IronPdf.HtmlToPdf();
            Uri url = new Uri("https://ironpdf.com/docs/questions/pdf-memory-stream/");

            MemoryStream rend = Renderer.RenderUrlAsPdf(url).Stream; //Read stream

            HttpContext.Current.Response.AddHeader("Content-Type", "application/pdf"); //Download

            HttpContext.Current.Response.AddHeader("Content-Disposition", String.Format("{0}; filename=Print.pdf; size={1}", "attachment", rend.Length.ToString()));

            // Write PDF buffer to HTTP response
            HttpContext.Current.Response.BinaryWrite(rend.ToArray());

            // Stop page processing
            HttpContext.Current.Response.End();
        }

        private void HTMLD3Chart()
        {
            var Renderer = new IronPdf.HtmlToPdf();
            Renderer.PrintOptions.EnableJavaScript = true;
            Renderer.PrintOptions.RenderDelay = 500;
            Renderer.PrintOptions.CssMediaType = PdfPrintOptions.PdfCssMediaType.Print;
            var PDF = Renderer.RenderHTMLFileAsPdf("Chart.html");

            var OutputPath = "HTMLD3Chart.pdf";
            PDF.SaveAs(OutputPath);

            PDF.SaveAs(OutputPath);

        }
        

    }
}